package com.app.to_do_list

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
